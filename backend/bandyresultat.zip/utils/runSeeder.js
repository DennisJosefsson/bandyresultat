const { runSeeder } = require('./seeder')

runSeeder()
