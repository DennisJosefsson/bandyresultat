const { rollbackSeeder } = require('./seeder')

rollbackSeeder()
